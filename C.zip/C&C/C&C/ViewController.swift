//
//  ViewController.swift
//  C&C
//
//  Created by Дмитрий Мякиньков on 15.06.2020.
//  Copyright © 2020 Дмитрий Мякиньков. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var convert: UIButton!
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var output: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func convAct(_ sender: UIButton) {
        let itemCost = Float(input.text!)
        var usdOut: Float = 0
        
        if sender.tag == 1
        {
            convert.isSelected = true
            let course: Float = 74
            usdOut = (itemCost!/course)
            usdOut = round(usdOut*100)/100
            output.text = "$"+String(usdOut)
        }
    }
    
}

